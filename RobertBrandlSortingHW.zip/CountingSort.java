package sorting;
//Robert Brandl Recitation: RI
//I pledge my honor that I have abided by the Stevens Honor System.

public class CountingSort {
	
	/**
	 * Calls the other sorting algorithm with A, B (a blank array of A.length), and integer k (the greatest value in A)
	 * @param A - the integer array to be sorted
	 */
	public static void sort (int[] A) {
		int k = 0;
		for (int i: A) {//finds the k value!
			if (i > k) {
				k=i;
			}
		}
		countingSort(A, new int[A.length], k);
	}
	
	/**
	 * Sorts a and places output into b using a temporary array c (length of k) using iteration (for loops)
	 * @param a - the array to be sorted
	 * @param b - the array to store the output
	 * @param k - the highest number in a
	 */
	private static void countingSort(int[] a, int[] b, int k) {
		int n = a.length;
		int[] c = new int[k+1];
		for (int i = 0; i < k; i++) {
			c[i] = 0;
		}
		for (int j = 0; j < n; j++) {
			c[a[j]]++;
		}
		//C[i] now contains the number of elements equal to i
		
		for (int i = 1; i <= k; i++) {
			c[i] = c[i] + c[i - 1];
		}
		// C[i] now contains the number of elements <= i
		
		for (int j = n - 1; j >= 0; j--) {
			b[c[a[j]]-1] = a[j];
			c[a[j]] = c[a[j]] - 1;
		}
		for (int i=0; i < n; i++) {
			a[i] = b[i];
		}

	}
	
	public static void main(String[] args) {
	}


}
