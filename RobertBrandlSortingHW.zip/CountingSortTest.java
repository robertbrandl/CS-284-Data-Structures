package sorting;
//Robert Brandl Recitation: RI
//I pledge my honor that I have abided by the Stevens Honor System.

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CountingSortTest {

	@Test
	void test1() {
		int[] a = {99,0,17,81};
		CountingSort.sort(a);
		assertTrue(a[0] == 0);
		assertTrue(a[1] == 17);
		assertTrue(a[2] == 81);
		assertTrue(a[3] == 99);
	}
	
	@Test
	void test2() {
		int[] a = {25, 9, 1000, 7};
		CountingSort.sort(a);
		assertTrue(a[0] == 7);
		assertTrue(a[1] == 9);
		assertTrue(a[2] == 25);
		assertTrue(a[3] == 1000);
	}
	
	@Test
	void test3() {
		int[] a = {10, 9};
		CountingSort.sort(a);
		assertTrue(a[0] == 9);
		assertTrue(a[1] == 10);
	}
	
	@Test
	void test4() {
		int[] a = {1, 2, 3, 0, 4};
		CountingSort.sort(a);
		assertTrue(a[0] == 0);
		assertTrue(a[1] == 1);
		assertTrue(a[2] == 2);
		assertTrue(a[3] == 3);
		assertTrue(a[4] == 4);
	}

}
